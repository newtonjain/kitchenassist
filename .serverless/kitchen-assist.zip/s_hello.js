
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'newtonjain',
  applicationName: 'kitchen-assist',
  appUid: 'd4PvKZpfJtNySPZQ1M',
  orgUid: 'DNRPXVjkKGr72dswYt',
  deploymentUid: 'cdeca762-b3a1-4a69-af90-0dac50ecd481',
  serviceName: 'kitchen-assist',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.17',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'kitchen-assist-dev-hello', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}