
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'newtonjain',
  applicationName: 'kitchen-assist',
  appUid: 'd4PvKZpfJtNySPZQ1M',
  orgUid: 'DNRPXVjkKGr72dswYt',
  deploymentUid: '54a565c2-80f3-43a3-9948-10ad258d6bec',
  serviceName: 'kitchen-assist',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.17',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'kitchen-assist-dev-hello', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}